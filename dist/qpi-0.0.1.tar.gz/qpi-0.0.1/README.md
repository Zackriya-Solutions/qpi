# Quick Process Integration

A library created to deploy your machine learning code as API in few lines of code.

## The project

This project is to make it easier for developers to deploy REST APIs faster for their ML models

## Install

``` $ pip3 install qpi ```


## Usage

``` $ py -m qpi --model model.ext --label label.txt --port 8000 --host false```
